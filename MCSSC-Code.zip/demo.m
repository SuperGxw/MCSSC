addpath(genpath('.'));

load('BBC.mat');
X = data;
real = truelabel{1}';

lambda = 10;
gamma = 5;
d = 10;
[Z, result] = MCSSC(X,real,lambda,d,gamma);





