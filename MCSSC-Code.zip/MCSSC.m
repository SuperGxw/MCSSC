function [Z, result] = MCSSC(X,gt,lambda,d,gamma)
% function [H, Z, grps, result] = MCSSC(X,gt,lambda,d,gamma)

V = size(X,2);
W = cell(1,V);
for i=1:V
        X{i} = X{i}./repmat(sqrt(sum(X{i}.^2,1)),size(X{i},1),1);
        W{i} = SPPMI(constructW_PKN(X{i},13), 2);  
end


% ---------------------------------- data pre-processing
m = size(W,2);  % mumber of views
n = size(W{1},2);   % number of samples
cls_num = size(unique(gt),1);   % number of clusters


% ----------------------------------------------initialize variables
for i = 1:m
    F{i} = eye(d,n);
%     F{i} = rand(d,n);
end

B = eye(n,d);
% B = rand(n,d);

Y1 = zeros(d,n);
Y2 = zeros(d,n);
Y3 = zeros(n,n);

H = B';
E = zeros(d,n);
Z = zeros(n,n);
J = Z;

% ----------------------------------------------
IsConverge = 0;
mu = 0.1;
pho = 1.5;
max_mu = 1e4;
max_iter = 100;
iter = 1;
thresh = 1e-1;
% ----------------------------------------------
while (IsConverge == 0&&iter<max_iter+1)
    
   
    sum_FFt = 0;
    sum_WFt = 0;
    
    for i = 1:m 
        % ---------------------------------- update F{i}
        F{i} = (B'*B)\(B'*W{i});
        sum_FFt = sum_FFt + F{i}*F{i}';
        sum_WFt = sum_WFt + W{i}*F{i}';
        F{i} = max(F{i},0);
    end
    
    % ---------------------------------- update B
    B = (sum_WFt+Y2'/mu+mu*H')/(sum_FFt+mu*eye(d));
    B = max(0,B);
    
    % ---------------------------------- update H
    H = ((E-Y1)*(eye(n)-Z)'+mu*B'-Y2/mu)/((eye(n)-Z)*(eye(n)-Z)'+mu*eye(n));
    
    % ---------------------------------- update Z
    Z = (mu*(H'*H+eye(n)))\(mu*H'*(H-E)+H'*Y1/mu+mu*J-mu*diag(diag(J))-Y3/mu);    
    
    % ---------------------------------- update E
    G = H-H*Z+Y1/mu;
    E = solve_l1l2(G,lambda/mu);
    
    % ---------------------------------- update J
    % Nuclear norm
    J = softth(Z+Y3/mu,gamma/mu);    

    % ---------------------------------- updata multipliers
    
    Y1 = Y1 + mu*(H-H*Z-E);
    Y2 = Y2 + mu*(H-B');
    Y3 = Y3 + mu*(Z-J+diag(diag(J)));    
    mu = min(pho*mu, max_mu);
    
    % ----------------------------------- convergence conditions    
    err1 = norm(H-H*Z-E,inf);
    err2 = norm(H-B',inf);
    err3 = norm(Z-J+diag(diag(J)),inf);
    max_err = max([err1,err2,err3]);   
    
    if max_err < thresh
        IsConverge = 1;
    end

    iter = iter + 1;
    
end
Z = (abs(Z) + abs(Z'))/2;
grps = SpectralClustering(Z,cls_num);
result = ClusteringMeasure_new(gt,grps);



